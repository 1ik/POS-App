jQuery(document).ready(function($) {
	$('input').attr('autocomplete' , 'off');

	$('.date').datepicker({
    });
});