<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Anik
 * Date: 10/14/13
 * Time: 9:13 AM
 * To change this template use File | Settings | File Templates.
 */

class Purchase_sizes extends CI_Controller{
    function __construct(){
        parent::__construct();
    }

}