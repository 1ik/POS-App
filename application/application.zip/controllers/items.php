<?php

/**

 * Created by JetBrains PhpStorm.

 * User: Anik

 * Date: 10/13/13

 * Time: 12:03 PM

 * To change this template use File | Settings | File Templates.

 */



class Items extends CI_Controller{

    function __construct(){

        parent::__construct();

        $this->load->model('item_model');
    }



    public function index(){

        // $data['vars']['items'] = $this->item_model->get_items();

        // $data['main_content'] = 'items/show';

        // $data['active'] = 'item';

        // $this->load->view('template' , $data);

    }



    public function purchase($id){
        is_staff();

        $data['vars']['purchase_id'] = $id;
        $data['vars']['items'] = $this->item_model->get_items('*' , array('purchases_id' => $id));
        $data['main_content'] = 'items/show';
        $data['active'] = 'item';
        $this->load->view('template' , $data);

    }



    public function show(){
        is_staff();

        if(!$this->input->post()){
            return;
        }

        $data['active'] = 'item';

        $designer_style = $this->input->post('designer_style');

        $data['vars']['items'] = $this->item_model->get_items('items.*' , array('designer_style' => $designer_style),array('purchases') );

        $this->session->set_flashdata('message' , "showing items with designer style : $designer_style");

        $data['main_content'] = 'items/show';

        $this->load->view('template' , $data);

    }



    /**
     * Takes barcode and retursn the item. it serves json requests.
     * @param $barcode the combination of YEAR_MONTH_ID .
     *
     */

    public function get_items_json($barcode , $showroom_id = 1){

        $item_object = $this->item_model->get_item_json($barcode , $showroom_id);

        echo json_encode($item_object);

    }



    /**
    * Gets the items in json format assosiated with the purchase id. (Only available in Headoffice.)
    */

    public function get_items_by_purchase_id($purchase_id){

        echo json_encode($this->item_model->get_items_by_purchase_id($purchase_id));

    }



    /**
    * Receives item's size name, color code in post request.
    * Returns showrooms having the items. Returns items number and showroom name and showroom locatoin in json array.
    */

    public function search() {
        if(!$this->_can_see_sell_info()) {
            redirect('auth');
        }

        if($this->input->post()) {

            echo json_encode($this->item_model->search());

        } else {

            $this->load->model("group_model");
            $data['groups'] = $this->group_model->get_groups();
            $data['page_name'] = 'Item search';
            $data['active'] = 'item';
            $data['vars'] = '';
            $data['main_content'] = 'items/search';
            $this->load->view('template' , $data);
        }
        //echo json_encode($this->item_model->search());
    }


    public function stock() {
        if($this->input->get()) {
            $get = $this->input->get();
            $groupby = '';
            $where = '';

            switch ($get['display']) {
                case "item-type":
                    $groupby = 'item_type.id';
                    break;
                case "size":
                    $groupby = 'size.id';
                    break;
                case "color":
                    $groupby = 'color_code';
                    break;
                case "style":
                    $groupby = 'designer_style';
                    break;                    
            }

            switch ($get["status"]) {
                case 'sold':
                    $where = "item.id in (select * from sold_item)";
                    break;
                case 'not_sold':
                    $where = "item.id not in (select * from sold_item)";
                    break;
                case "both" :
                    $where = '';
            }

            if($get['showroom_id'] != -1) {
                if( $where != '' ) {
                    $where .= " and ";
                }
                $where .= " showroom.id = ".$get['showroom_id'];
            }

            if($get['designer_style'] != '') {
                if($where != '') {
                    $where .= " and ";
                }

                $where .= " item.designer_style = '".$get['designer_style']."'";
            }
            

            $this->load->model('item_model');
            $data['vars']['rows'] = $this->item_model->get_stock($where, $groupby);

        } else {
            $data['vars'] = '';            
        }

        $this->load->model('showroom_model');
        $data['showrooms'] = $this->showroom_model->get('*');    
        $data['page_name'] = 'Item stock information';
        $data['active'] = 'item_stock';
        $data['main_content'] = 'items/stock';
        $data['links'] = array(anchor('items/stock' , 'Stock information') , anchor('items/purchase_data' , "purchase information"));
        $this->load->view('template' , $data);
    }



    public function purchase_data() {
        if($this->input->get()) {
            $this->load->model('item_model');
            $data['vars']['rows'] = $this->item_model->get_purchase_info();
        } else {            
            $data['vars'] = '';
        }

        $data['page_name'] = "purchase infromatoin";
        $data['main_content'] = "items/purchase_info";
        $data['links'] = array(anchor('items/stock' , 'Stock information') , anchor('items/purchase_data' , "purchase information"));
        $data['active'] = 'item_stock';
        $this->load->view('template' , $data);
    }


    private function _can_see_sell_info() {
        $CI =& get_instance();

        if($CI->ion_auth->in_group('members' , $CI->ion_auth->get_user_id()) || $CI->ion_auth->in_group('staff' , $CI->ion_auth->get_user_id()) || !$CI->ion_auth->in_group('admin' , $CI->ion_auth->get_user_id())) {
            return true;
        }
        return false;
    }

}